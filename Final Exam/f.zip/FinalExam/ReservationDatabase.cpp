// ReservationDatabase.cpp
// Member-function definitions for class ReservationDatabase.
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace::std;
#include "ReservationDatabase.h" // ReservationDatabase class definition

void ReservationDatabase::loadFromReservations()
{

}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

unsigned int ReservationDatabase::numReservations( string IDNumber )
{

}

void ReservationDatabase::displayReservations( string IDNumber )
{

}

void ReservationDatabase::saveToReservationFile()
{

}