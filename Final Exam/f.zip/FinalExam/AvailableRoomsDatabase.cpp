// AvailableRoomsDatabase.cpp
// Member-function definitions for class AvailableRoomsDatabase.
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
#include "AvailableRoomsDatabase.h" // AvailableRoomsDatabase class definition

extern bool leapYear( unsigned int year );

void AvailableRoomsDatabase::loadAvailableRooms()
{

}

void AvailableRoomsDatabase::initilizeAvailableRooms()
{

}

void AvailableRoomsDatabase::adjustAvailableRooms()
{

}

void AvailableRoomsDatabase::displayAvailableRooms( const Date &checkInDate, const Date &checkOutDate )
{

}

unsigned int AvailableRoomsDatabase::findMinNumRooms( unsigned int roomType,
                             const Date &checkInDate, const Date &checkOutDate )
{

}

void AvailableRoomsDatabase::decreaseAvailableRooms( unsigned int roomType, unsigned int numRooms,
                                                     const Date &checkInDate, const Date &checkOutDate )
{

}

void AvailableRoomsDatabase::saveAvailableRooms()
{

}

void AvailableRoomsDatabase::findIterators( const Date &checkInDate, const Date &checkOutDate,
                                            vector< AvailableRooms >::iterator &checkInIterator,
                                            vector< AvailableRooms >::iterator &checkOutIterator )
{

}