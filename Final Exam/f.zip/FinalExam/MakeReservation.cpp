// MakeReservation.cpp
// Member-function definitions for class MakeReservation.
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
#include "MakeReservation.h" // MakeReservation class definition

// extern bool legalID( const string &id );
extern bool leapYear( unsigned int year );

// MakeReservation constructor initializes base-class data members
MakeReservation::MakeReservation( ReservationDatabase &theReservationDatabase,
                                  AvailableRoomsDatabase &theAvailableRoomsDatabase )
   : reservationDatabase( theReservationDatabase ),
     availableRoomsDatabase( theAvailableRoomsDatabase )
{
} // end MakeReservation constructor

// performs transaction
void MakeReservation::execute()
{

}

void MakeReservation::computeAvailableMonths( Date currentDate, Date availableMonths[] )
{
}

void MakeReservation::inputCheckInDates( Date &checkInDate, Date currentDate, Date availableMonths[], unsigned int &checkInYMCode, unsigned int &firstDay, unsigned int &lastDay )
{

}

void MakeReservation::inputCheckOutDates( Date &checkOutDate, Date checkInDate, Date availableMonths[],
   unsigned int checkInYMCode, unsigned int firstDay, unsigned int lastDay )
{

}